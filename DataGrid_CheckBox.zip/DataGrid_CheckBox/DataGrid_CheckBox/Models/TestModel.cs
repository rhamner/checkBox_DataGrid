﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Mvvm;

namespace DataGrid_CheckBox
{
    public class TestModel : BindableBase
    {
        private bool _checked;
        private string _displayText;
        private bool _enabled;
        private List<TestModel> _dependents;
        private List<TestModel> _dependsOn;

        public bool Checked
        {
            get
            {
                return _checked;
            }
            set
            {
                SetProperty(ref _checked, value);
                RaisePropertyChanged("Checked");
            }
        }

        public string DisplayText
        {
            get
            {
                return _displayText;
            }
            set
            {
                SetProperty(ref _displayText, value);
            }
        }

        public List<TestModel> Dependents
        {
            get
            {
                return _dependents;
            }
            set
            {
                SetProperty(ref _dependents, value);
            }
        }

        public bool Enabled
        {
            get
            {
                return _enabled;
            }
            set
            {
                SetProperty(ref _enabled, value);
            }
        }

        public List<TestModel> DependsOn
        {
            get
            {
                return _dependsOn;
            }
            set
            {
                SetProperty(ref _dependsOn, value);
            }
        }

        public TestModel()
        {
            Checked = true;
            Enabled = true;
            Dependents = new List<TestModel>();
            DependsOn = new List<TestModel>();
        }
    }
}
