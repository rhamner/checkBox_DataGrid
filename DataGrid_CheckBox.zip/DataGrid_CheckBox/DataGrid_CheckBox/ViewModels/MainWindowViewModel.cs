﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Mvvm;
using Prism.Commands;
using System.Windows.Input;

namespace DataGrid_CheckBox
{
    public class MainWindowViewModel : BindableBase
    {
        private ObservableCollection<TestModel> _displayElements;
        public ObservableCollection<TestModel> DisplayElements
        {
            get
            {
                return _displayElements;
            }
            set
            {
                SetProperty(ref _displayElements, value);
            }
        }

        public ICommand CheckAllCommand { get; set; }

        public MainWindowViewModel()
        {

            //build collection so that all elements can trigger property changed handler and so that 2nd and 4th elements depend on 1st
            //and 4th depends on 2nd
            DisplayElements = new ObservableCollection<TestModel>();
            TestModel first = new TestModel();
            first.DisplayText = "First";
            first.PropertyChanged += Grid_PropertyChanged;
            DisplayElements.Add(first);
            TestModel second = new TestModel();
            second.DisplayText = "Second";
            second.PropertyChanged += Grid_PropertyChanged;
            DisplayElements.Add(second);
            TestModel third = new TestModel();
            third.DisplayText = "Third";
            third.PropertyChanged += Grid_PropertyChanged;
            DisplayElements.Add(third);
            TestModel fourth = new TestModel();
            fourth.DisplayText = "Frouth";
            fourth.PropertyChanged += Grid_PropertyChanged;
            DisplayElements.Add(fourth);
            first.Dependents.Add(second);
            second.Dependents.Add(fourth);
            third.Dependents.Add(fourth);
            fourth.DependsOn.Add(first);
            fourth.DependsOn.Add(second);
            fourth.DependsOn.Add(third);
            second.DependsOn.Add(first);

            //Command triggered when checkbox in header is selected...select all on true...deselect all and set enabled based on
            //dependencies if false
            CheckAllCommand = new DelegateCommand<object>((param) =>
            {
                foreach (TestModel test in DisplayElements)
                {
                    if ((bool)param)
                    {
                        test.Checked = true;
                        test.Enabled = true;
                    }
                    else
                    {
                        test.Checked = false;
                        RecursiveSet(test);
                    }
                }
            });

        }

        //if checkbox clicked anywhere but header, trigger this...sender will be clicked checkbox
        private void Grid_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            RecursiveSet(sender as TestModel);
        }

        //recursively walk through rows and set the checkbox state (recursion since rows can depend on each other)
        private void RecursiveSet(TestModel initTest)
        {
            if(initTest.Checked)
            {
                foreach(TestModel test in initTest.Dependents)
                {
                    //handle situation where step depends on multiple other steps...only enable if all the steps it depends on
                    //are checked
                    if (test.DependsOn.Any(p => p.Checked == false))
                    {
                        test.Enabled = false;
                    }
                    else
                    {
                        test.Enabled = true;
                    }
                    if (test.Dependents.Count > 0)
                    {
                        RecursiveSet(test);
                    }
                }
            }
            else
            {
                foreach(TestModel test in initTest.Dependents)
                {
                    test.Checked = false;
                    test.Enabled = false;
                    if (test.Dependents.Count > 0)
                    {
                        RecursiveSet(test);
                    }
                }
            }
        }
    }
}
